export interface User {
    id: string;
    fullName: string;
    sex: string;
    age: number;
    matchedYou: boolean;
}